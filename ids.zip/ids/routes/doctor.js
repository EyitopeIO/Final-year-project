const express = require("express")
const router = express.Router()
const bcrypt = require('bcrypt')
const Joi = require('@hapi/joi')
const Hospital = require("../models/hospital")
const Doctor = require("../models/doctor")
const Patient = require("../models/patient")
const Lab_attendant = require("../models/lab_attendant")
const Sample = require("../models/sample")
const Journey = require("../models/journey")
const saltRounds = 10

const redirectLogin = (req, res, next) => {
    if(!req.session.doctorLoggedIn){
        res.redirect("/doctor/login")
    }else{
        next()
    }
}

const redirectHome = (req, res, next) => {
    if(req.session.doctorLoggedIn){
        res.redirect("/doctor/dashboard")
    }else{
        next()
    }
}

router.get("/login", redirectHome, async(req, res) => {
    res.render("doctors/login", {email: '', password: '', error_message: ''})
})

router.post("/login", redirectHome, async(req, res) => {
    var error_message = ''
    const schema = Joi.object({
        email: Joi.string().email(),
        password: Joi.string().pattern(/^[a-zA-Z0-9]{5,32}$/)
    })

    const {error, value} = schema.validate(req.body)

    if(error){
        switch(error.details[0].context.key){
            case 'email':
                error_message = 'Please Provide Email Of Doctor'
                res.render("doctors/login", {
                    name: req.body.name, email: req.body.email, password: req.body.password, error_message: error_message
                })
                break
            case 'password':
                error_message = 'Please Provide Password for Doctor'
                res.render("doctors/login", {
                    name: req.body.name, email: req.body.email, password: req.body.password, error_message: error_message
                })
                break
            default:
                break;
        }
    }

    try{
        // console.log(req.body)
        const doctor = await Doctor.findOne({email: req.body.email}).exec()

        if(doctor != null){
            bcrypt.compare(req.body.password, doctor.password, (err, state) => {
                if(state == false){
                    res.render("doctors/login", {
                        name: req.body.name, email: req.body.email, password: req.body.password, error_message: 'Password is Incorrect'
                    })
                }else if(state == true){
                    // res.send("Details are very correct provided")
                    req.session.doctorLoggedIn = true
                    req.session.doctorId = doctor._id
                    req.flash('success', "Doctor Logged In Successfully")
                    res.redirect('/doctor/dashboard')
                }
            })
        }else{
            res.render("doctors/login", {
                name: req.body.name, email: req.body.email, password: req.body.password, error_message: "Doctor Not Found!"
            })
        }
    }catch(e){
        console.log(e)
        message = "Doctor Email Provided Not Found!"

        if(e.name === 'MongoError' && e.code === 11000){
            message = "Doctor Email Already Exists"
        }
        res.render("doctors/login", {name: req.body.name, email: req.body.email, password: req.body.password, error_message: message})
    }
})

router.get("/dashboard", redirectLogin, async(req, res) => {
    let patient = 0
    try{
        const doctor = await Doctor.findOne({_id: req.session.doctorId})
        const hospitalId = doctor.hospitalId
        const samples = await Sample.find({hospital: hospitalId, doctor: req.session.doctorId})
        console.log(samples, hospitalId, req.session.doctorId)
        Sample.distinct('patient', (err, result) => {
            if(err){
                res.send(err)
            }
            if(result){
                patient = result.length
                res.render("doctors/dashboard",{samples: samples, patient: patient})
            }
        })
    }catch(e){
        console.log(e)
        res.send("Error On dashboard Page")
    }
})

router.get("/samples", redirectLogin, async(req, res) => {
    try{
        const doctor = await Doctor.findOne({_id: req.session.doctorId}).exec()
        // console.log(doctor)
        const samples = await Sample.find({doctor: doctor._id}).populate("hospital patient hospital")
        console.log(samples)
        res.render("doctors/samples", {
          request: {}, error_message: '', samples: samples
        })
    }catch(e){
        console.log(e)
        res.send("Error On Samples Page")
    }
})

router.get("/profile", redirectLogin, async(req, res) => {
    try{
        const doctor = await Doctor.findOne({_id: req.session.doctorId}).exec()
        // console.log(doctor)
        res.render("doctors/profile", {
          request: {}, error_message: '', doctor: doctor
        })
    }catch(e){
        console.log(e)
        res.send("Error On Samples Page")
    }
})

router.get("/sample/:id/history", redirectLogin, async(req, res) => {
    try{
        const sample = await Sample.findOne({_id: req.params.id}).exec()
        const journeys = await Journey.find({sample: req.params.id}).populate("sample")
        // console.log(sample)
        res.render("doctors/history", {
          request: {}, error_message: '',sample: sample,journeys: journeys
        })
    }catch(e){
        console.log(e)
        res.send("Error On Samples History Page")
    }
})

router.get("/sample/journey/:id/map", redirectLogin, async(req, res) => {
    try{
        const journey = await Journey.findOne({_id: req.params.id}).populate("sample")
        res.render("doctors/single_map", {
          request: {}, error_message: '',journey: journey
        })
    }catch(e){
        console.log(e)
        res.send("Error On Samples History Page")
    }
})
/*

router.get("/patients", redirectLogin, async(req, res) => {
    try{
        const patients = await Samples.find({doctor: req.session.doctorId})
        res.render("doctors/patients", {
          request: {}, error_message: '', patients: patients
        })
    }catch(e){
        console.log(e)
        res.send("Error On Patients Page")
    }
})
*/

router.get("/logout", redirectLogin, async(req, res) => {
    req.session.destroy(err => {
        if(err){
            return res.redirect("/doctor/dashboard")
        }
        res.clearCookie("sid")
        return res.redirect("/doctor/login")
    })
})

module.exports = router
