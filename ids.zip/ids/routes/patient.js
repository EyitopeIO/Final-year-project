const express = require("express")
const router = express.Router()
const bcrypt = require('bcrypt')
const Joi = require('@hapi/joi')
const Hospital = require("../models/hospital")
const Doctor = require("../models/doctor")
const Patient = require("../models/patient")
const Lab_attendant = require("../models/lab_attendant")
const Sample = require("../models/sample")
const Journey = require("../models/journey")
const saltRounds = 10

const redirectLogin = (req, res, next) => {
    if(!req.session.patientLoggedIn){
        res.redirect("/patient/login")
    }else{
        next()
    }
}

const redirectHome = (req, res, next) => {
    if(req.session.patientLoggedIn){
        res.redirect("/patient/dashboard")
    }else{
        next()
    }
}

router.get("/login", redirectHome, async(req, res) => {
    res.render("patients/login", {email: '', password: '', error_message: ''})
})

router.post("/login", redirectHome, async(req, res) => {
    var error_message = ''
    const schema = Joi.object({
        email: Joi.string().email(),
        password: Joi.string().pattern(/^[a-zA-Z0-9]{5,32}$/)
    })

    const {error, value} = schema.validate(req.body)

    if(error){
        switch(error.details[0].context.key){
            case 'email':
                error_message = 'Please Provide Email Of Patient'
                res.render("patients/login", {
                    name: req.body.name, email: req.body.email, password: req.body.password, error_message: error_message
                })
                break
            case 'password':
                error_message = 'Please Provide Password for Patient'
                res.render("patients/login", {
                    name: req.body.name, email: req.body.email, password: req.body.password, error_message: error_message
                })
                break
            default:
                break;
        }
    }

    try{
        const patient = await Patient.findOne({email: req.body.email}).exec()
        console.log(patient)

        if(patient != null){
            bcrypt.compare(req.body.password, patient.password, (err, state) => {
                if(state == false){
                    res.render("patients/login", {
                        name: req.body.name, email: req.body.email, password: req.body.password, error_message: 'Password is Incorrect'
                    })
                }else if(state == true){
                    // res.send("Details are very correct provided")
                    req.session.patientLoggedIn = true
                    req.session.patientId = patient._id
                    req.flash('success', "Patient Logged In Successfully")
                    res.redirect('/patient/dashboard')
                }
            })
        }else{
            res.render("patients/login", {
                name: req.body.name, email: req.body.email, password: req.body.password, error_message: "Patient Not Found!"
            })
        }
    }catch(e){
        console.log(e)
        message = "Patient Email Provided Not Found!"

        if(e.name === 'MongoError' && e.code === 11000){
            message = "Patient Email Already Exists"
        }
        res.render("patients/login", {name: req.body.name, email: req.body.email, password: req.body.password, error_message: message})
    }
})

router.get("/dashboard", redirectLogin, async(req, res) => {
    try{
        const patient = await Patient.findOne({_id: req.session.patientId}).exec()
        const samples = await Sample.find({patient: patient._id})
        res.render("patients/dashboard", {samples: samples})
    }catch(e){
        console.log(e)
        res.send("Error On Samples Page")
    }
})

router.get("/samples", redirectLogin, async(req, res) => {
    try{
        const patient = await Patient.findOne({_id: req.session.patientId}).exec()
        // console.log(doctor)
        const samples = await Sample.find({patient: patient._id}).populate("hospital patient doctor")
        console.log(samples)
        res.render("patients/samples", {
          request: {}, error_message: '', samples: samples, patient: patient
        })
    }catch(e){
        console.log(e)
        res.send("Error On Samples Page")
    }
})

router.get("/profile", redirectLogin, async(req, res) => {
    try{
        const patient = await Patient.findOne({_id: req.session.patientId}).exec()
        // console.log(doctor)
        res.render("patients/profile", {
          request: {}, error_message: '', patient: patient
        })
    }catch(e){
        console.log(e)
        res.send("Error On Samples Page")
    }
})

router.get("/sample/:id/history", redirectLogin, async(req, res) => {
    try{
        const sample = await Sample.findOne({_id: req.params.id}).exec()
        const journeys = await Journey.find({sample: req.params.id}).populate("sample")
        // console.log(sample)
        res.render("patients/history", {
          request: {}, error_message: '',sample: sample,journeys: journeys
        })
    }catch(e){
        console.log(e)
        res.send("Error On Samples History Page")
    }
})

router.get("/sample/journey/:id/map", redirectLogin, async(req, res) => {
    try{
        const journey = await Journey.findOne({_id: req.params.id}).populate("sample")
        res.render("patients/single_map", {
          request: {}, error_message: '',journey: journey
        })
    }catch(e){
        console.log(e)
        res.send("Error On Samples History Page")
    }
})
/*

router.get("/patients", redirectLogin, async(req, res) => {
    try{
        const patients = await Samples.find({doctor: req.session.patientId})
        res.render("patients/patients", {
          request: {}, error_message: '', patients: patients
        })
    }catch(e){
        console.log(e)
        res.send("Error On Patients Page")
    }
})
*/

router.get("/logout", redirectLogin, async(req, res) => {
    req.session.destroy(err => {
        if(err){
            return res.redirect("/patient/dashboard")
        }
        res.clearCookie("sid")
        return res.redirect("/patient/login")
    })
})

module.exports = router
