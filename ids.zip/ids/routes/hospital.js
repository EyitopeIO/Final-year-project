const express = require("express")
const router = express.Router()
const bcrypt = require('bcrypt')
const Joi = require('@hapi/joi')
const Result = require("../models/result")
const Hospital = require("../models/hospital")
const Doctor = require("../models/doctor")
const Patient = require("../models/patient")
const Lab_attendant = require("../models/lab_attendant")
const Sample = require("../models/sample")
const Journey = require("../models/journey")
const saltRounds = 10

const redirectLogin = (req, res, next) => {
    if(!req.session.hospitalLoggedIn){
        res.redirect("/hospital/login")
    }else{
        next()
    }
}

const redirectHome = (req, res, next) => {
    if(req.session.hospitalLoggedIn){
        res.redirect("/hospital/dashboard")
    }else{
        next()
    }
}

router.get("/dashboard", redirectLogin, async(req, res) => {
    try{
        const doctors = await Doctor.find({hospitalId: req.session.hospitalId})
        const patients = await Patient.find({hospitalId: req.session.hospitalId})
        const lab_attendants = await Lab_attendant.find({hospitalId: req.session.hospitalId})
        const samples = await Sample.find({hospital: req.session.hospitalId})
        // console.log(doctors.length)
        res.render("hospital/dashboard", {
          request: {}, error_message: '', doctors: doctors, patients: patients,lab_attendants: lab_attendants, samples: samples
        })
    }catch(e){
        console.log(e)
        res.send("Error On Samples Page")
    }
})

router.get("/samples", redirectLogin, async(req, res) => {
    try{
        const samples = await Sample.find({hospital: req.session.hospitalId}).populate("patient doctor hospital lab_attendant")
        // res.json({results})
        res.render("hospital/samples", {
          request: {}, error_message: '', samples: samples
        })
    }catch(e){
        console.log(e)
        res.send("Error On Samples Page")
    }
})

router.get("/journey/:id/:sample_id/delete", redirectLogin, async(req, res) => {
    try{
        await Journey.deleteOne({_id: req.params.id})
        res.redirect("/hospital/sample/" + req.params.sample_id + "/history")
    }catch(e){
        console.log(e)
        res.send("Error On Sample Deleting Page")
    }
})

router.get("/results/:sample_id", redirectLogin, async(req,res) => {
    try{
        const sample = await Sample.findOne({_id: req.params.sample_id}).populate("hospital").exec()
        const results = await Result.find({receiver: req.session.hospitalId}).populate("sample hospital")
        console.log(req.params.sample_id, req.session.hospitalId)
        res.render("hospital/results", {
          request: {}, error_message: '', sample: sample, results: results
        })
    }catch(e){
        console.log(e)
        res.send("Error On Results Page")
    }
})

router.get("/arriving/results/:sample_id", redirectLogin, async(req,res) => {
    try{
        const sample = await Sample.findOne({_id: req.params.sample_id}).populate("hospital").exec()
        const results = await Result.find({sample: req.params.sample_id, hospital: req.session.hospitalId}).populate("sample hospital")
        res.render("hospital/arriving_sample_results", {
          request: {}, error_message: '', sample: sample, results: results
        })
    }catch(e){
        console.log(e)
        res.send("Error On Results Page")
    }
})

router.get("/result/create/:id", redirectLogin, async(req, res) => {
    try{
        const sample = await Sample.findOne({_id: req.params.id}).populate("hospital").exec()
        const results = await Result.find({sample: req.params.id}).populate("hospital")
        console.log(results.length)
        if(results.length > 0){
            req.flash('success', "Result Already Submitted!")
            // console.log("Passed here")
            res.redirect("/hospital/arriving/results/" + sample._id)
        }else{
            res.render("hospital/create_result", {
                request: {}, error_message: '', sample: sample
            })
        }
    }catch(e){
        console.log(e)
        res.send("Error on result creation page")
    }
})

router.post("/result/create/:id", redirectLogin, async(req, res) => {
    var error_message = ''// console.log(samples)
    const sample = await Sample.findOne({_id: req.params.id}).populate("hospital").exec()
    const schema = Joi.object({
        sample: Joi.string().required(),
        result: Joi.string().required()
    })

    const {error, value} = schema.validate(req.body)

    if(error){
        switch(error.details[0].context.key){
            case 'sample':
                error_message = 'Please Provide Sample'
                res.render("hospital/create_result", {
                    request: req.body, error_message: error_message,sample: sample
                })
                break
            case 'result':
                error_message = 'Please Provide Result of Sample'
                res.render("hospital/create_result", {
                    request: req.body, error_message: error_message,sample: sample
                })
                break
            default:
                break;
        }
    }

    req.body.hospital = req.session.hospitalId
    req.body.receiver = sample.hospital;
    // console.log(req.body)
    // res.json({sample})
    try{
        const result = await Result.create(req.body)
        req.flash('success', "Result Submitted Successfully!")
        res.redirect("/hospital/arriving/results/" + sample._id)
    }catch(e){
        console.log(e)
        if(e.name === 'MongoError' && e.code === 11000){
            message = "Something Already Exists"
        }else{
            message = "Some Other Error(s) are there yo!"
        }
        res.render("hospital/create_result", {request: req.body, error_message: message, sample: sample})
    }
})

router.get("/arriving_samples", redirectLogin, async(req, res) => {
    try{
        const samples = await Sample.find({arrivingHospital: req.session.hospitalId}).populate("patient doctor hospital lab_attendant")
        // console.log(samples)
        res.render("hospital/arriving_samples", {
          request: {}, error_message: '', samples: samples
        })
    }catch(e){
        console.log(e)
        res.send("Error On Samples Page")
    }
})

router.get("/sample/:id/move", redirectLogin, async (req, res) => {
    try{
        const samples = await Sample.find({default: true})
        samples.map(async sample => {
            sample.default = false
            await sample.save()
        })
        const sample = await Sample.findOne({_id: req.params.id})
        sample.default = true
        await sample.save()
        res.redirect("/hospital/samples")
    }catch(e){
        console.log(e)
        res.send("Error On Samples Movement Settings Page")
    }
})

router.get("/sample/:id/stop/moving", redirectLogin, async(req, res) => {
    try{
        const sample = await Sample.findOne({_id: req.params.id})
        sample.default = false
        await sample.save()
        res.redirect("/hospital/samples")
    }catch(e){
        console.log(e)
        res.send("Error On Samples Movement Settings Page")
    }
})

router.get("/maps", redirectLogin, async(req, res) => {
    try{
        // const samples = await Sample.find({}).populate("patient doctor hospital lab_attendant")
        // console.log(samples)
        res.render("hospital/maps", {
          request: {}, error_message: ''
        })
    }catch(e){
        console.log(e)
        res.send("Error On Samples Page")
    }
})

router.get("/sample/:id/history", redirectLogin, async(req, res) => {
    try{
        const sample = await Sample.findOne({_id: req.params.id}).exec()
        const journeys = await Journey.find({sample: req.params.id}).populate("sample")
        // console.log(await Journey.find({}))
        res.render("hospital/history", {
           request: {}, error_message: '',sample: sample,journeys: journeys
        })
    }catch(e){
        console.log(e)
        res.send("Error On Samples History Page")
    }
})

router.get("/sample/journey/:id/map", redirectLogin, async(req, res) => {
    try{
        const journey = await Journey.findOne({_id: req.params.id}).populate("sample")
        res.render("hospital/single_map", {
          request: {}, error_message: '',journey: journey
        })
    }catch(e){
        console.log(e)
        res.send("Error On Samples History Page")
    }
})

router.get("/sample/:id/motion", redirectLogin, async(req, res) => {
    try{
        const sample = await Sample.findOne({_id: req.params.id}).exec()
        const journeys = await Journey.find({sample: req.params.id}).populate("sample")
        const len = journeys.length
        const sample_id = req.params.id
        // console.log(sample)
        res.render("hospital/map_in_motion", {
          request: {}, error_message: '',journeys: journeys,sample: sample,len: len, sample_id: sample_id
        })
    }catch(e){
        console.log(e)
        res.send("Error On Samples History Page")
    }
})

//Doctors Module

router.get("/doctors", redirectLogin, async(req, res) => {

    try{
        const doctors = await Doctor.find({hospitalId: req.session.hospitalId})
        res.render("hospital/doctors", {
          request: {}, error_message: '', doctors: doctors
        })
    }catch(e){
        console.log(e)
        res.send("Error On Doctors Page")
    }
})

router.get("/doctor/create", redirectLogin, async(req, res) => {
    res.render("hospital/create_doctor", {
        request: {}, error_message: ''
    })
})

router.post("/doctor/create", redirectLogin, async(req, res) => {
    var error_message = ''
    const schema = Joi.object({
        full_name: Joi.string().required(),
        email: Joi.string().email(),
        phone: Joi.string().pattern(/^[0-9]{11,32}$/),
        staff_id: Joi.string().required(),
        password: Joi.string().pattern(/^[a-zA-Z0-9]{5,32}$/)
    })

    const {error, value} = schema.validate(req.body)

    if(error){
        switch(error.details[0].context.key){
            case 'full_name':
                error_message = 'Please Provide Full Name Of Doctor'
                res.render("hospital/create_doctor", {
                    request: req.body, error_message: error_message
                })
                break
            case 'email':
                error_message = 'Please Provide Email Address Of Doctor'
                res.render("hospital/create_doctor", {
                    request: req.body, error_message: error_message
                })
                break
            case 'phone':
                error_message = 'Please Provide Phone Number of Doctor'
                res.render("hospital/create_doctor", {
                    request: req.body, error_message: error_message
                })
                break
            case 'staff_id':
                error_message = 'Please Provide Staff ID of Doctor'
                res.render("hospital/create_doctor", {
                    request: req.body, error_message: error_message
                })
                break
            case 'password':
                error_message = 'Please Provide Password Of Doctor'
                res.render("hospital/create_doctor", {
                    request: req.body, error_message: error_message
                })
                break
            default:
                break;
        }
    }

    try{
        var salt = bcrypt.genSaltSync(saltRounds)
        var hash = bcrypt.hashSync(req.body.password, salt)
        req.body.password = hash
        req.body.hospitalId = req.session.hospitalId
        const doctor = await Doctor.create(req.body)
        req.flash('success', "Doctor Account Created Successfully!")
        res.redirect("/hospital/doctors")
    }catch(e){
        console.log(e)
        if(e.name === 'MongoError' && e.code === 11000){
            message = "Doctor Email Or Phone Or Staff ID Already Exists"
        }else{
            message = "Some Other Error(s) are there yo!"
        }
        res.render("hospital/create_doctor", {request: req.body, error_message: message})
    }
})

//Patient Module

router.get("/patients", redirectLogin, async(req, res) => {

    try{
        const patients = await Patient.find({hospitalId: req.session.hospitalId})
        res.render("hospital/patients", {
          request: {}, error_message: '', patients: patients
        })
    }catch(e){
        console.log(e)
        res.send("Error On Patients Page")
    }
})

router.get("/patient/create", redirectLogin, async(req, res) => {
    res.render("hospital/create_patient", {
        request: {}, error_message: ''
    })
})

router.post("/patient/create", redirectLogin, async(req, res) => {
    var error_message = ''
    const schema = Joi.object({
        full_name: Joi.string().required(),
        email: Joi.string().email(),
        phone: Joi.string().pattern(/^[0-9]{11,32}$/),
        password: Joi.string().pattern(/^[a-zA-Z0-9]{5,32}$/)
    })

    const {error, value} = schema.validate(req.body)

    if(error){
        switch(error.details[0].context.key){
            case 'full_name':
                error_message = 'Please Provide Full Name Of Patient'
                return res.render("hospital/create_patient", {
                    request: req.body, error_message: error_message
                })
                break
            case 'email':
                error_message = 'Please Provide Email Address Of Patient'
                return res.render("hospital/create_patient", {
                    request: req.body, error_message: error_message
                })
                break
            case 'phone':
                error_message = 'Please Provide Phone Number of Patient'
                return res.render("hospital/create_patient", {
                    request: req.body, error_message: error_message
                })
                break
            case 'password':
                error_message = 'Please Provide Password Of Patient'
                return res.render("hospital/create_patient", {
                    request: req.body, error_message: error_message
                })
                break
            default:
                break;
        }
    }

    try{
        var salt = bcrypt.genSaltSync(saltRounds)
        var hash = bcrypt.hashSync(req.body.password, salt)
        req.body.password = hash
        req.body.hospitalId = req.session.hospitalId
        const patient = await Patient.create(req.body)
        req.flash('success', "Patient Account Created Successfully!")
        res.redirect("/hospital/patients")
    }catch(e){
        console.log(e)
        if(e.name === 'MongoError' && e.code === 11000){
            message = "Patient Email Or Phone Already Exists"
        }else{
            message = "Some Other Error(s) are there yo!"
        }
        res.render("hospital/create_patient", {request: req.body, error_message: message})
    }
})

//Lab Attendant Module

router.get("/lab_attendants", redirectLogin, async(req, res) => {

    try{
        const lab_attendants = await Lab_attendant.find({hospitalId: req.session.hospitalId})
        res.render("hospital/lab_attendants", {
          request: {}, error_message: '', lab_attendants: lab_attendants
        })
    }catch(e){
        console.log(e)
        res.send("Error On Lab Attendants Page")
    }
})

router.get("/lab_attendant/create", redirectLogin, async(req, res) => {
    res.render("hospital/create_lab_attendant", {
        request: {}, error_message: ''
    })
})

router.post("/lab_attendant/create", redirectLogin, async(req, res) => {
    var error_message = ''
    const schema = Joi.object({
        full_name: Joi.string().required(),
        email: Joi.string().email(),
        phone: Joi.string().pattern(/^[0-9]{11,32}$/),
        password: Joi.string().pattern(/^[a-zA-Z0-9]{5,32}$/)
    })

    const {error, value} = schema.validate(req.body)

    if(error){
        switch(error.details[0].context.key){
            case 'full_name':
                error_message = 'Please Provide Full Name Of Lab Attendant'
                return res.render("hospital/create_lab_attendant", {
                    request: req.body, error_message: error_message
                })
                break
            case 'email':
                error_message = 'Please Provide Email Address Of Lab Attendant'
                return res.render("hospital/create_lab_attendant", {
                    request: req.body, error_message: error_message
                })
                break
            case 'phone':
                error_message = 'Please Provide Phone Number of Lab Attendant'
                return res.render("hospital/create_lab_attendant", {
                    request: req.body, error_message: error_message
                })
                break
            case 'password':
                error_message = 'Please Provide Password Of Lab Attendant'
                return res.render("hospital/create_lab_attendant", {
                    request: req.body, error_message: error_message
                })
                break
            default:
                break;
        }
    }

    try{
        var salt = bcrypt.genSaltSync(saltRounds)
        var hash = bcrypt.hashSync(req.body.password, salt)
        req.body.password = hash
        req.body.hospitalId = req.session.hospitalId
        const lab_attendant = await Lab_attendant.create(req.body)
        req.flash('success', "Lab Attendant Account Created Successfully!")
        res.redirect("/hospital/lab_attendants")
    }catch(e){
        console.log(e)
        if(e.name === 'MongoError' && e.code === 11000){
            message = "Lab Attendant Email Or Phone Already Exists"
        }else{
            message = "Some Other Error(s) are there yo!"
        }
        res.render("hospital/create_lab_attendant", {request: req.body, error_message: message})
    }
})

router.get("/login", redirectHome, async(req, res) => {
    res.render("hospital/login", {email: '', password: '', error_message: ''})
})

router.post("/login", redirectHome, async(req, res) => {
    var error_message = ''
    const schema = Joi.object({
        email: Joi.string().email(),
        password: Joi.string().pattern(/^[a-zA-Z0-9]{5,32}$/)
    })

    const {error, value} = schema.validate(req.body)

    if(error){
        switch(error.details[0].context.key){
            case 'email':
                error_message = 'Please Provide Email Of Hospital'
                res.render("hospital/login", {
                    name: req.body.name, email: req.body.email, password: req.body.password, error_message: error_message
                })
                break
            case 'password':
                error_message = 'Please Provide Password for Hospital'
                res.render("hospital/login", {
                    name: req.body.name, email: req.body.email, password: req.body.password, error_message: error_message
                })
                break
            default:
                break;
        }
    }

    try{
        // console.log(req.body)
        const hospital = await Hospital.findOne({email: req.body.email}).exec()

        if(hospital != null){
            bcrypt.compare(req.body.password, hospital.password, (err, state) => {
                if(state == false){
                    res.render("hospital/login", {
                        name: req.body.name, email: req.body.email, password: req.body.password, error_message: 'Password is Incorrect'
                    })
                }else if(state == true){
                    // res.send("Details are very correct provided")
                    req.session.hospitalLoggedIn = true
                    req.session.hospitalId = hospital._id
                    req.flash('success', "Hospital Logged In Successfully")
                    res.redirect('/hospital/dashboard')
                }
            })
        }else{
            res.render("hospital/login", {
                name: req.body.name, email: req.body.email, password: req.body.password, error_message: "Hospital Not Found!"
            })
        }
    }catch(e){
        console.log(e)
        message = "Hospital Email Provided Not Found!"

        if(e.name === 'MongoError' && e.code === 11000){
            message = "Hospital Email Already Exists"
        }
        res.render("hospital/login", {name: req.body.name, email: req.body.email, password: req.body.password, error_message: message})
    }
})

router.get("/register", redirectHome, async(req, res) => {
    res.render("hospital/register", {email: '', password: '', name :'', error_message: ''})
})

router.post("/register", redirectHome, async(req, res) => {
    var error_message = ''
    const schema = Joi.object({
        name: Joi.string().min(8).max(100).required(),
        email: Joi.string().email(),
        password: Joi.string().pattern(/^[a-zA-Z0-9]{5,32}$/)
    })

    const {error, value} = schema.validate(req.body)

    if(error){
        switch(error.details[0].context.key){
            case 'name':
                error_message = 'Please Provide Name Of Hospital'
                return res.render("hospital/register", {
                    name: req.body.name, email: req.body.email, password: req.body.password, error_message: error_message
                })
                break
            case 'email':
                error_message = 'Please Provide Correct Email Of Hospital'
                return res.render("hospital/register", {
                    name: req.body.name, email: req.body.email, password: req.body.password, error_message: error_message
                })
                break
            case 'password':
                error_message = 'Please Provide Password for Hospital'
                return res.render("hospital/register", {
                    name: req.body.name, email: req.body.email, password: req.body.password, error_message: error_message
                })
                break
            default:
                break;
        }
    }

    try{
        var salt = bcrypt.genSaltSync(saltRounds)
        var hash = bcrypt.hashSync(req.body.password, salt)
        req.body.password = hash
        const hospital = await Hospital.create(req.body)
        req.flash('success', "Hospital Account Created Successfully!")
        res.redirect("/hospital/login")
    }catch(e){
        if(e.name === 'MongoError' && e.code === 11000){
            message = "Hospital Email Already Exists"
        }else{
            message = "Some Other Error(s) are there yo!"
        }
        console.log(e)
        // console.log(message)
        res.render("hospital/register", {name: req.body.name, email: req.body.email, password: req.body.password, error_message: message})
    }
})

router.get("/logout", redirectLogin, async(req, res) => {
    req.session.destroy(err => {
        if(err){
            return res.redirect("/hospital/dashboard")
        }
        res.clearCookie("sid")
        return res.redirect("/hospital/login")
    })
})

module.exports = router;
