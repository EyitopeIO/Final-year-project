const mongoose = require("mongoose")

const resultSchema = new mongoose.Schema({
    hospital: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: "Hospital"
    },
    receiver: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: "Hospital"
    },
    sample: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: "Sample"
    },
    result: {
        type: String,
        required: true
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
})

module.exports = mongoose.model("Result", resultSchema)
