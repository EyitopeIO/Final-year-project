const express = require("express")
const router = express.Router()
const Journey = require("../models/journey")
const Sample = require("../models/sample")

router.post("/sample/details/save", async(req, res) => {
    // console.log(req.body)
    // console.log(await Sample.find({default: true}))
    // await Sample.remove({})
    // res.json({stopped:true})
    try {
        const sample = await Sample.findOne({default: true}).exec()
        if(sample != null){
            req.body.sample = sample._id
            const journey = await Journey.create(req.body)
            // console.log(sample)
            // console.log(journey)
            res.json({status:1, message:"Data Saved Successfully", data: req.body})
        }else{
            res.json({status:-1, message:"No Sample is on the move at the moment"})
        }
    } catch (e) {
        let error_message = []
        for(key in e.errors){
            error = {}
            console.log(key)
            error.key = e.errors[key].message
            error_message.push(error)
        }
        res.json({status:-1, message:"Error At Endpoint", data: req.body, error: error_message})
    }
})

router.post("/journey", async(req, res) => {
    try{
        const journey = await Journey.find({sample: req.body.sample, stopped: false}).populate("sample").sort({createdAt: -1})
        // console.log("All the journey data coming now\n\n")
        // console.log(journey.length)

        if(journey != null && journey.length > 0){
            const last_journey = journey[journey.length - 1]
            last_journey.stopped = true
            await last_journey.save()
            const new_journeys = await Journey.find({sample: req.body.sample, stopped: false})
            console.log(new_journeys.length)
            res.json({status: 1,message: "journey data",journey: last_journey})
        }else{
            res.json({status: -1,message: "journey data not found"})
        }
    }catch(e){
        console.log(e);
        res.json({status:-1, message:"Error At Endpoint", data: req.body})
    }
})

module.exports = router;
